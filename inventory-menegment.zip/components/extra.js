
            <div ref={reportRef}

                className={`bg-white min-w-[894px] min-h-[1123px] w-[994px] p-8 text-black mx-auto  rounded shadow-lg   hidden`}
            >
                <div

                    style={{
                        width: '894px',
                        height: 'auto',
                        margin: '0 auto',
                        border: '1px solid #b91c1c',
                        fontFamily: 'Cambria, serif',
                        fontSize: '12px',
                        backgroundColor: '#ffffff',
                        color: '#000',
                        wordSpacing: '2px',
                        letterSpacing: '0.5px',
                        boxSizing: 'border-box',
                        position: 'relative',
                        marginTop: '20px',
                        padding: '0',
                        overflow: 'hidden',
                        fontWeight: 'bold',
                        textAlign: 'center'

                    }}
                >
                    {/* Header */}
                    <div style={{ paddingBottom: '10px' }}>
                        <p style={{ textAlign: 'right', margin: 0, padding: 10 }}>Mo. 9979524096,9023137786</p>
                        <h1
                            style={{
                                color: '#b91c1c',
                                fontSize: '20px',
                                fontWeight: 'bold',
                                textAlign: 'center',
                                margin: '5px 0',
                                textTransform: 'uppercase',
                            }}
                        >
                            Sai Service
                        </h1>
                        <p style={{ textAlign: 'center', fontWeight: 'bold', margin: '2px 0' }}>
                            All Type DTH Recharge Service & Sales LED TV, CCTV Camera
                        </p>
                        <p style={{ textAlign: 'center', color: '#b91c1c', margin: '2px 0' }}>
                            (કુલાર, પંખા, ઈલેક્ટ્રોનિક્સ વસ્તુઓ મળશે.)
                        </p>
                        <p
                            style={{
                                textAlign: 'center',
                                borderTop: '1px solid #000',
                                // borderBottom: '1px solid #000',
                                padding: '1px 0',
                                margin: '10px 0',
                                fontWeight: 'bold',
                                itemsAlign: 'center',
                                justifyItems: 'center'

                            }}
                        >
                            A.T. Post. Pipalkhed, (Bus stop Pachhal) Shop No. 2, Ta. Vansda Dist. Navsari.
                        </p>

                        {/* Info Row */}
                        <div
                            style={{
                                padding: '0 10px ',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'stretch',
                                borderTop: '1px solid #000',
                                borderBottom: '1px solid #000',
                            }}
                        >
                            {/* Client Info */}
                            <div style={{ width: '60%', textAlign: 'left', paddingRight: '10px', padding: '2px', fontSize: '13px' }}>
                                <p style={{ wordSpacing: '2px', letterSpacing: '0.5px' }}><strong>Name : </strong>   {(invoice.client ?? '_________________')
                                    .toLowerCase()
                                    .split(' ')
                                    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                    .join(' ')}</p>
                                <p><strong>Address : </strong>{(invoice?.clientAddress || '_________________')
                                    .toLowerCase()
                                    .split(' ')
                                    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                    .join(' ')}</p>
                                <p><strong>Mobile : </strong> {invoice?.clientPhone || '________________'}</p>
                            </div>

                            {/* Invoice Info */}
                            <div
                                style={{
                                    width: '40%',
                                    paddingLeft: '10px',
                                    borderLeft: '1px solid #000',
                                    textAlign: 'right',
                                }}
                            >
                                <p>
                                    <strong>Bill No:</strong>{' '}
                                    <span style={{ fontSize: '16px', fontWeight: 'bold' }}>
                                        {invoice?.invoiceNumber || '201'}
                                    </span>
                                </p>
                                <p>
                                    <strong>Date:</strong>{' '}
                                    {invoice?.date ? new Date(invoice.date).toLocaleDateString('en-GB') : '- / - / 20'}
                                </p>
                            </div>
                        </div>

                    </div>

                    {/* Table */}
                    <div style={{ marginTop: '20px', padding: '0 10px' }}>
                        <table
                            style={{
                                width: '100%',
                                borderCollapse: 'collapse',
                                border: '1px solid #000',
                                textAlign: 'center',
                            }}
                        >
                            <thead>
                                <tr style={{ backgroundColor: '#fee2e2', fontSize: '12px' }}>
                                    <th style={cellHeader}>No.</th>
                                    <th style={cellHeader}>PRODUCT DESCRIPTION</th>
                                    <th style={cellHeader}>Qty.</th>
                                    <th style={cellHeader}>Unit Rate</th>
                                    <th style={cellHeader}>Amount Rs.</th>
                                </tr>
                            </thead>
                            <tbody style={{ fontSize: '14px' }}>
                                {(invoice?.items || []).map((item, index) => (
                                    <tr key={index}>
                                        <td style={cellBody}>{index + 1}</td>
                                        <td style={{ ...cellBody, textAlign: 'left' }}>
                                            <div>
                                                {item.item_name
                                                    .toLowerCase()
                                                    .split(' ')
                                                    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                                                    .join(' ')}
                                            </div>

                                            {/* Model Number */}
                                            {item?.item_model && (
                                                <div style={{ color: 'gray', fontSize: '13px', paddingLeft: '8px' }}>
                                                    Model No: {item.item_model}
                                                </div>
                                            )}

                                            {/* Serial Number */}
                                            {item?.item_serial && (
                                                <div style={{ fontSize: '13px', paddingLeft: '8px' }}>
                                                    Serial no./IMEI No.: {item.item_serial}
                                                </div>
                                            )}
                                            {/* Brand & Category */}
                                            <div style={{ display: 'flex', gap: '8px', color: 'gray', fontSize: '13px', paddingLeft: '8px' }}>
                                                {item?.item_brand && <div>{item.item_brand}</div>}
                                                {item?.item_catagory && <div>{item.item_catagory}</div>}
                                            </div>

                                            {invoice?.note && (
                                                <div style={{ fontSize: '13px', paddingLeft: '8px', color: "gray" }}>
                                                    (Notes : {invoice?.note})
                                                </div>
                                            )}
                                        </td>


                                        <td style={cellBody}>{item.item_quantity}</td>
                                        <td style={cellBody}>₹{item.item_price.toFixed(2)}</td>
                                        <td style={cellBody}>
                                            ₹{(item.item_quantity * item.item_price).toFixed(2)}
                                        </td>
                                    </tr>
                                ))}
                                {/* Blank Rows */}
                                {Array.from({ length: Math.max(12 - (invoice?.items?.length || 0), 0) }).map((_, i) => (
                                    <tr key={`blank-${i}`}>
                                        <td style={cellBody}>&nbsp;</td>
                                        <td style={cellBody}>&nbsp;</td>
                                        <td style={cellBody}>&nbsp;</td>
                                        <td style={cellBody}>&nbsp;</td>
                                        <td style={cellBody}>&nbsp;</td>
                                    </tr>
                                ))}
                            </tbody>
                            <tfoot>
                                <tr>
                                    {/* Warranty column - spans first 2 columns */}
                                    <td colSpan={3}
                                        style={{
                                            border: '1px solid #000',
                                            padding: '6px',
                                            fontWeight: 'bold',
                                            textAlign: 'left',
                                            backgroundColor: '#f9f9f9',
                                        }}
                                    >
                                        Warranty: {invoice?.warranty || 'N/A'}
                                    </td>

                                    {/* Empty filler cell for spacing */}


                                    {/* TOTAL label cell */}
                                    <td
                                        style={{
                                            border: '1px solid #000',
                                            padding: '6px',
                                            textAlign: 'right',
                                            fontWeight: 'bold',
                                            backgroundColor: '#f3f3f3',
                                        }}
                                    >
                                        TOTAL:
                                    </td>

                                    {/* TOTAL amount cell */}
                                    <td
                                        style={{
                                            border: '1px solid #000',
                                            padding: '6px',
                                            textAlign: 'center',
                                            fontWeight: 'bold',
                                            backgroundColor: '#f3f3f3',
                                        }}
                                    >
                                        ₹{invoice?.grandTotal?.toFixed(2) || '0.00'}
                                    </td>
                                </tr>
                            </tfoot>

                        </table>
                    </div>

                    {/* Footer Totals */}
                    <div
                        style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginTop: '20px',
                            fontSize: '12px',
                            padding: '12px',

                        }}
                    >
                        <p>Customer I.D.: {(invoice?.customerID || '_________________________')}</p>

                    </div>



                    {/* Signature */}
                    <div
                        style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'flex-end',
                            marginTop: '40px',
                            fontSize: '12px',
                            padding: '10px',
                        }}
                    >
                        <p style={{ fontStyle: 'italic' }}>Received Signature…</p>
                        <p style={{ fontWeight: 'bold' }}>For, Sai Service</p>
                    </div>
                </div>

            </div>